package principal;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Programa SERVIDOR. Fica esperando conexões e entrega cada uma para uma
 * ThreadServer própria.
 */
public class Principal {

    private static final int PORTA = 12345;

    public static void main(String[] args) {
        try (ServerSocket servidorSocket = new ServerSocket(PORTA)) {
            System.out.println("Servidor aguardando conexões na porta " + PORTA);
            while (true) {
                try {
                    Socket clienteSocket = servidorSocket.accept();
                    System.out.println("Conexão aceita de " + clienteSocket.getInetAddress());

                    // uma Thread nova para cada cliente
                    Thread threadCliente = new ThreadServer(clienteSocket);
                    threadCliente.start();

                } catch (Exception ex) {
                    // um problema com UM cliente não pode derrubar o servidor
                    System.out.println("Erro ao aceitar conexão do cliente: " + ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.out.println("Erro ao criar o ServerSocket (porta " + PORTA
                    + " já em uso?): " + ex.getMessage());
        }
    }
}
