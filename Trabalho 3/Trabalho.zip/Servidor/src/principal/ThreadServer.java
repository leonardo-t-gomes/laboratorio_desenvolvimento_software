package principal;

import beans.Pessoa;
import dao.PessoaDAO;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;

/**
 * Atende UM cliente. O Principal cria uma instância desta Thread para cada
 * conexão aceita, então vários clientes são atendidos ao mesmo tempo.
 */
public class ThreadServer extends Thread {

    private final Socket clienteSocket;

    public ThreadServer(Socket clienteSocket) {
        this.clienteSocket = clienteSocket;
    }

    @Override
    public void run() {
        String origem = clienteSocket.getInetAddress().getHostAddress();
        System.out.println("[" + getName() + "] atendendo " + origem);

        // try-with-resources: o socket é sempre fechado, mesmo se der erro
        try (Socket socket = clienteSocket) {
            socket.setSoTimeout(30000); // cliente mudo não prende a Thread para sempre

            // out primeiro (e flush), depois in: evita travar esperando o cabeçalho
            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            String resposta;
            try {
                Object recebido = in.readObject();
                if (recebido instanceof Pessoa) {
                    resposta = cadastrar((Pessoa) recebido);
                } else {
                    resposta = "erro: o objeto recebido não é uma Pessoa";
                }
            } catch (ClassNotFoundException ex) {
                resposta = "erro: classe desconhecida pelo servidor (" + ex.getMessage() + ")";
            }

            out.writeObject(resposta);
            out.flush();
            System.out.println("[" + getName() + "] resposta enviada: " + resposta);

        } catch (Exception ex) {
            // qualquer problema de comunicação fica restrito a ESTA Thread
            System.out.println("[" + getName() + "] erro ao lidar com o cliente " + origem
                    + ": " + ex.getMessage());
        }
    }

    /** Tenta inserir no banco e devolve "sucesso..." ou "erro: motivo". */
    private String cadastrar(Pessoa p) {
        PessoaDAO dao = new PessoaDAO();
        try {
            dao.inserir(p);
            return "sucesso: " + p.getNome().trim() + " cadastrado(a) com o id " + p.getId();
        } catch (SQLException ex) {
            System.out.println("[" + getName() + "] erro SQL: " + ex.getMessage());
            return "erro: " + traduzir(ex);
        } catch (Exception ex) {
            System.out.println("[" + getName() + "] erro inesperado: " + ex);
            return "erro: " + ex.getMessage();
        } finally {
            dao.fechar();
        }
    }

    /** Deixa as mensagens mais comuns do MySQL mais amigáveis. */
    private String traduzir(SQLException ex) {
        String msg = ex.getMessage() == null ? "erro desconhecido no banco" : ex.getMessage();
        String coluna = entreAspas(msg);
        switch (ex.getErrorCode()) {
            case 1048: // Column 'nome' cannot be null
                return "o campo obrigatório '" + coluna + "' não foi preenchido";
            case 1406: // Data too long for column 'nome' at row 1
                return "o valor informado é grande demais para o campo '" + coluna + "'";
            default:
                return msg;
        }
    }

    /** Pega o texto entre as primeiras aspas simples da mensagem do MySQL. */
    private String entreAspas(String msg) {
        int ini = msg.indexOf('\'');
        int fim = msg.indexOf('\'', ini + 1);
        return (ini >= 0 && fim > ini) ? msg.substring(ini + 1, fim) : "?";
    }
}
