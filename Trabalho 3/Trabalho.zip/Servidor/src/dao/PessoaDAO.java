package dao;

import beans.Pessoa;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PessoaDAO {

    private final Connection conn;

    public PessoaDAO() {
        this.conn = new Conexao().getConexao(); // null se o banco estiver fora do ar
    }

    /**
     * Insere a pessoa no banco. Ao contrário da versão da aula, NÃO engole a
     * exceção: ela sobe para o chamador (ThreadServer), que transforma em
     * mensagem de erro para o cliente.
     */
    public void inserir(Pessoa pessoa) throws SQLException {
        if (conn == null) {
            throw new SQLException("não foi possível conectar ao banco de dados");
        }
        String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?,?,?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            // texto vazio vira NULL, assim o NOT NULL do banco rejeita o cadastro
            stmt.setString(1, vazioParaNull(pessoa.getNome()));
            stmt.setString(2, vazioParaNull(pessoa.getSexo()));
            stmt.setString(3, vazioParaNull(pessoa.getIdioma()));
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    pessoa.setId(rs.getInt(1));
                }
            }
        }
    }

    /** Fecha a conexão com o banco (cada atendimento abre e fecha a sua). */
    public void fechar() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ex) {
                System.out.println("Erro ao fechar conexão: " + ex.getMessage());
            }
        }
    }

    private String vazioParaNull(String s) {
        if (s == null || s.trim().isEmpty()) {
            return null;
        }
        return s.trim();
    }
}
