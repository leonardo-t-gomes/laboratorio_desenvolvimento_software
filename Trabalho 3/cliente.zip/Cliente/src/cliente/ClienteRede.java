package cliente;

import beans.Pessoa;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;


public class ClienteRede {

    public static final String HOST = "localhost";
    public static final int PORTA = 12345;

    public static String enviar(Pessoa pessoa) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(HOST, PORTA), 3000); 
            socket.setSoTimeout(10000);                               

            ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

            out.writeObject(pessoa);
            out.flush();

            return String.valueOf(in.readObject());

        } catch (ConnectException ex) {
            return "erro: servidor indisponível em " + HOST + ":" + PORTA
                    + " (ele está em execução?)";
        } catch (SocketTimeoutException ex) {
            return "erro: o servidor demorou demais para responder";
        } catch (IOException ex) {
            return "erro: falha na comunicação com o servidor (" + ex.getMessage() + ")";
        } catch (ClassNotFoundException ex) {
            return "erro: resposta inválida do servidor";
        }
    }
}
