package cliente;

import beans.Pessoa;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.WindowConstants;


public class CadastroPessoa extends JFrame {

    private static final String[] IDIOMAS = {"Português", "Inglês", "Espanhol", "Francês"};

    private final JTextField txtNome = new JTextField(20);
    private final JRadioButton rbMasculino = new JRadioButton("Masculino");
    private final JRadioButton rbFeminino = new JRadioButton("Feminino");
    private final JComboBox<String> cbIdioma = new JComboBox<>(IDIOMAS);
    private final JButton btnCadastrar = new JButton("Cadastrar");
    private final JTextArea txtResposta = new JTextArea(3, 20);

    public CadastroPessoa() {
        super("Cadastro de Pessoa");
        montarTela();
    }

    private void montarTela() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        ButtonGroup grupoSexo = new ButtonGroup();
        grupoSexo.add(rbMasculino);
        grupoSexo.add(rbFeminino);
        JPanel painelSexo = new JPanel();
        painelSexo.add(rbMasculino);
        painelSexo.add(rbFeminino);

        txtResposta.setEditable(false);
        txtResposta.setLineWrap(true);
        txtResposta.setWrapStyleWord(true);
        txtResposta.setFont(txtResposta.getFont().deriveFont(Font.BOLD));
        txtResposta.setBorder(BorderFactory.createTitledBorder("Resposta do servidor"));

        btnCadastrar.addActionListener(evt -> cadastrar());

        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 5, 5);
        c.anchor = GridBagConstraints.WEST;

        c.gridx = 0; c.gridy = 0;
        painel.add(new JLabel("Nome:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL; c.weightx = 1;
        painel.add(txtNome, c);

        c.gridx = 0; c.gridy = 1; c.fill = GridBagConstraints.NONE; c.weightx = 0;
        painel.add(new JLabel("Sexo:"), c);
        c.gridx = 1;
        painel.add(painelSexo, c);

        c.gridx = 0; c.gridy = 2;
        painel.add(new JLabel("Idioma:"), c);
        c.gridx = 1; c.fill = GridBagConstraints.HORIZONTAL;
        painel.add(cbIdioma, c);

        c.gridx = 0; c.gridy = 3; c.gridwidth = 2; c.fill = GridBagConstraints.NONE;
        c.anchor = GridBagConstraints.CENTER;
        painel.add(btnCadastrar, c);

        c.gridy = 4; c.fill = GridBagConstraints.HORIZONTAL;
        painel.add(txtResposta, c);

        setContentPane(painel);
        getRootPane().setDefaultButton(btnCadastrar); // Enter = Cadastrar
        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);
    }

    private void cadastrar() {
        String sexo = null;
        if (rbMasculino.isSelected()) {
            sexo = "M";
        } else if (rbFeminino.isSelected()) {
            sexo = "F";
        }
        Pessoa pessoa = new Pessoa(txtNome.getText(), sexo, (String) cbIdioma.getSelectedItem());

        btnCadastrar.setEnabled(false);
        txtResposta.setForeground(Color.DARK_GRAY);
        txtResposta.setText("Enviando para o servidor...");

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                return ClienteRede.enviar(pessoa);
            }

            @Override
            protected void done() {
                String resposta;
                try {
                    resposta = get();
                } catch (Exception ex) {
                    resposta = "erro: " + ex.getMessage();
                }
                mostrarResposta(resposta);
                btnCadastrar.setEnabled(true);
            }
        }.execute();
    }

    private void mostrarResposta(String resposta) {
        boolean sucesso = resposta.toLowerCase().startsWith("sucesso");
        txtResposta.setForeground(sucesso ? new Color(0, 128, 0) : Color.RED);
        txtResposta.setText(resposta);
        if (sucesso) {
            txtNome.setText("");
            txtNome.requestFocusInWindow();
        }
    }

    public static void main(String[] args) {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // segue com o visual padrão
        }
        SwingUtilities.invokeLater(() -> new CadastroPessoa().setVisible(true));
    }
}
