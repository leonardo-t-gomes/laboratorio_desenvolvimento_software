package dao;

import beans.Pessoa;
import beans.Veiculo;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;

public class VeiculoDAO {

    private Conexao conexao;
    private Connection conn;

    public VeiculoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    public void inserir(Veiculo veiculo) {
        String sql = "INSERT INTO veiculo (modelo, placa, id_pessoa) VALUES (?, ?, ?);";

        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, veiculo.getModelo());
            stmt.setString(2, veiculo.getPlaca());
            stmt.setInt(3, veiculo.getPessoaid().getId());

            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir Veiculo: " + ex.getMessage());
        }
    }

    public void editar(Veiculo veiculo) {
        String sql = "UPDATE veiculo SET modelo=?, placa=?, id_pessoa=? WHERE id=?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, veiculo.getModelo());
            stmt.setString(2, veiculo.getPlaca());
            stmt.setInt(3, veiculo.getPessoaid().getId());
            stmt.setInt(4, veiculo.getId());
            stmt.execute();

            System.out.println("Veículo atualizado com sucesso!");
        } catch (SQLException ex) {
            System.out.println("Erro ao atualizar Veiculo: " + ex.getMessage());
        }
    }

    public void excluir(int id) {
        try {
            String sql = "delete from veiculo WHERE id=?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir veículo: " + ex.getMessage());
        }
    }

    public List<Veiculo> getVeiculos() {
        String sql = "SELECT * FROM veiculo";
        List<Veiculo> listaVeiculos = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(sql); ResultSet rs = stmt.executeQuery()) {

            PessoaDAO pDAO = new PessoaDAO(); // Instanciado fora do loop

            while (rs.next()) {
                Veiculo v = new Veiculo();
                v.setId(rs.getInt("id"));
                v.setModelo(rs.getString("modelo"));
                v.setPlaca(rs.getString("placa"));

                Pessoa p = pDAO.getPessoa(rs.getInt("id_pessoa"));
                v.setPessoaid(p);

                listaVeiculos.add(v);
            }
        } catch (SQLException ex) {
            System.out.println("Erro ao consultar todos os veículos: " + ex.getMessage());
        }

        return listaVeiculos; // Retorna a lista (preenchida ou vazia caso dê erro)
    }

    public Veiculo getVeiculo(int id) {
        String sql = "SELECT * FROM veiculo WHERE id = ?";

        try {
            PreparedStatement stmt = conn.prepareStatement(sql,
                    ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_UPDATABLE);

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            Veiculo v = new Veiculo();

            rs.first();

            v.setId(rs.getInt("id"));
            v.setModelo(rs.getString("modelo"));
            v.setPlaca(rs.getString("placa"));

            PessoaDAO pDAO = new PessoaDAO();

            Pessoa p = pDAO.getPessoa(rs.getInt("id_pessoa"));
            v.setPessoaid(p);

            return v;

        } catch (SQLException ex) {
            System.out.println("Erro ao consultar pessoa: " + ex.getMessage());
            return null;
        }
    }
}
