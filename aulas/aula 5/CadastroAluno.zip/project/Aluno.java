/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author User
 */
public class Aluno {
    private String nome;
    private String dataNascimento;
    private char sexo;
    private String matricula;
    private String curso;
    private String cpf;
    private String endereco;
    private String estado;
    private String telefone;

    public Aluno(String nome, String dataNascimento, char sexo, String matricula,
                 String curso, String cpf, String endereco, String estado, String telefone) {
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.matricula = matricula;
        this.curso = curso;
        this.cpf = cpf;
        this.endereco = endereco;
        this.estado = estado;
        this.telefone = telefone;
    }

    // ---- Getters (necessários para ArquivoAluno e para a JTable) ----
    public String getNome() { return nome; }
    public String getDataNascimento() { return dataNascimento; }
    public char getSexo() { return sexo; }
    public String getMatricula() { return matricula; }
    public String getCurso() { return curso; }
    public String getCpf() { return cpf; }
    public String getEndereco() { return endereco; }
    public String getEstado() { return estado; }
    public String getTelefone() { return telefone; }

    @Override
    public String toString() {
        return "Aluno{" +
                "nome=" + nome +
                ", dataNascimento=" + dataNascimento +
                ", sexo=" + sexo +
                ", matricula=" + matricula +
                ", curso=" + curso +
                ", cpf=" + cpf +
                ", endereco=" + endereco +
                ", estado=" + estado +
                ", telefone=" + telefone +
                '}';
    }

    /**
     * Retorna os dados do aluno como um array de objetos,
     * na ordem em que devem aparecer nas colunas da JTable.
     */
    public Object[] obterDados() {
        return new Object[]{
            nome,
            dataNascimento,
            sexo,
            matricula,
            curso,
            cpf,
            endereco,
            estado,
            telefone
        };
    }
}
