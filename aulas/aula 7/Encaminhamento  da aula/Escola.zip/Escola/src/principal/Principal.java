/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package principal;

import Beans.Aluno;
import Beans.Professor;
import conexao.Conexao;
import DAO.AlunoDAO;
import DAO.ProfessorDAO;


/**
 *
 * @author laboratorio
 */
public class Principal {
    public static void main(String[] args) {
        Conexao c = new Conexao();
        c.getConexao();
        Aluno a = new Aluno();
        a.setNome("Leonardo Gomes");
        a.setIdade(19);
        a.setCurso("Ciência Computação");
        AlunoDAO pdao = new AlunoDAO();
        pdao.inserir(a);
        
        Professor p = new Professor();
        p.setNome("Gabriel Fachim");
        p.setIdade(25);
        p.setDisciplina("Redes Computadores");
       ProfessorDAO pdao2 = new ProfessorDAO();
        pdao2.inserir(p);
    }
    
}
