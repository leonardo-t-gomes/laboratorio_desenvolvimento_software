/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Beans.Aluno;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author User
 */
public class AlunoDAO {
    private Conexao conexao;
    private Connection conn;

    public AlunoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    public void inserir (Aluno aluno){
        try {
            String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,aluno.getNome());
            stmt.setInt(2,aluno.getIdade());
            stmt.setString(3,aluno.getCurso());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir Aluno:"+ex.getMessage());
        }
    }
    
    public Aluno getAluno(int id){
        String sql = "SELECT *FROM pessoa WHERE id = ?";
        
        try{
            PreparedStatement stat = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stat.setInt(1, id);
            ResultSet rs = stat.executeQuery();
            Aluno p = new Aluno();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("Nome"));
            p.setIdade(rs.getInt("sexo"));
            p.setCurso(rs.getString("Curso"));
            return p;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar Aluno"+ex.getMessage());
            return null;
        }
    }
    
    public void editar(Aluno aluno){
        try { 
            String sql = "UPDATE pessoa set nome =?, sexo=?, idioma=? WHERE id=?";
            
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, aluno.getNome());
            stat.setInt(2, aluno.getIdade());
            stat.setString(3, aluno.getCurso());
            stat.setInt(4, aluno.getId());
            stat.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao atualizar pessoa: "+ex.getMessage());
        }
    }
    
public void excluir(String nome){
    String sql = "DELETE FROM pessoa WHERE nome = ?";
    try {
        PreparedStatement stat = conn.prepareStatement(sql);
        stat.setString(1, nome);
        stat.execute();
        stat.close();
        System.out.println("Aluno excluído com sucesso!");
    } catch (SQLException ex) {
        System.out.println("Erro ao excluir Aluno: " + ex.getMessage());
    }
}
     
}
