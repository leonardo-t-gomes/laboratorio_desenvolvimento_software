/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Beans.Professor;
import java.sql.Connection;
import conexao.Conexao;
import java.util.List;
import java.sql.*;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author User
 */
public class ProfessorDAO {
    private Conexao conexao;
    private Connection conn;

    public ProfessorDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
           public List<Professor> getProfessorNome(String nome){
        String sql = "SELECT * FROM pessoa WHERE nome LIKE ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stmt.setString(1, "%"+ nome +"%");
            ResultSet rs = stmt.executeQuery();
            List <Professor> listaProfessor = new ArrayList();
            
            while (rs.next()){
                Professor p = new Professor();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setIdade(rs.getInt("idade"));
                p.setDisciplina(rs.getString("disciplina"));
                listaProfessor.add(p);
            }
            return listaProfessor;
        } catch (SQLException ex){ 
            System.out.println("Erro ao consultar todas as pessoas: "+ex.getMessage());
            return null;
        }
    }
    
    public List<Professor> getProfessor(){
        String sql = "SELECT * FROM pessoa";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Professor> listaProfessor = new ArrayList();
            
            while (rs.next()){
                Professor p = new Professor();
                p.setId(rs.getInt("id"));
                p.setNome(rs.getString("nome"));
                p.setIdade(rs.getInt("idade"));
                p.setDisciplina(rs.getString("disciplina"));
                listaProfessor.add(p);
            }
            
            return listaProfessor;
        } catch (SQLException ex) {
            System.out.println("Erro de consultar todas as pessoas: "+ex.getMessage());
            return null;
        }
    } 
    
    public void inserir (Professor profesor){
        try {
            String sql = "INSERT INTO pessoa(nome, sexo, idioma) VALUES (?,?,?);";
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1,profesor.getNome());
            stmt.setInt(2,profesor.getIdade());
            stmt.setString(3,profesor.getDisciplina());
            
            stmt.execute();
        } catch (SQLException ex) {
            System.out.println("Erro ao inserir Professor:"+ex.getMessage());
        }
    }
     
    public Professor getProfessor(int id){
        String sql = "SELECT *FROM pessoa WHERE id = ?";
        
        try{
            PreparedStatement stat = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            stat.setInt(1, id);
            ResultSet rs = stat.executeQuery();
            Professor p = new Professor();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("Nome"));
            p.setIdade(rs.getInt("sexo"));
            p.setDisciplina(rs.getString("Disciplina"));
            return p;
        } catch (SQLException ex){
            System.out.println("Erro ao consultar Aluno"+ex.getMessage());
            return null;
        }
    }
    
    public void editar(Professor professor){
        try { 
            String sql = "UPDATE pessoa set nome =?, sexo=?, idioma=? WHERE id=?";
            
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setString(1, professor.getNome());
            stat.setInt(2, professor.getIdade());
            stat.setString(3, professor.getDisciplina());
            stat.setInt(4, professor.getId());
            stat.execute();
        } catch (SQLException ex){
            System.out.println("Erro ao atualizar pessoa: "+ex.getMessage());
        }
    }
    
     public void excluir(int id){
        String sql = "DELETE FROM pessoa WHERE id = ?";
        try {
            PreparedStatement stat = conn.prepareStatement(sql);
            stat.setInt(1, id);
            stat.execute();
            stat.close();
        } catch (SQLException ex) {
            System.out.println("Erro ao excluir Aluno: " + ex.getMessage());
        }
    }
}
